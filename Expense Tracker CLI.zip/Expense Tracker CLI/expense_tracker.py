import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import os

DB_NAME = "expenses.db"
EXPORT_DIR = "exports"

# -------------------------------
# Database Setup
# -------------------------------
def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT,
        category TEXT,
        amount REAL,
        type TEXT
    )
    """)

    conn.commit()
    conn.close()


# -------------------------------
# Add Entry
# -------------------------------
def add_entry():
    date = input("Enter date (YYYY-MM-DD) or press Enter for today: ")
    if not date:
        date = datetime.today().strftime("%Y-%m-%d")

    category = input("Enter category: ")
    amount = float(input("Enter amount: "))
    t_type = input("Type (income/expense): ").lower()

    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO transactions (date, category, amount, type)
        VALUES (?, ?, ?, ?)
    """, (date, category, amount, t_type))

    conn.commit()
    conn.close()

    print("✅ Entry added successfully!")


# -------------------------------
# Monthly Summary
# -------------------------------
def monthly_summary():
    month = input("Enter month (YYYY-MM): ")

    conn = sqlite3.connect(DB_NAME)
    df = pd.read_sql_query("SELECT * FROM transactions", conn)
    conn.close()

    if df.empty:
        print("⚠️ No data found.")
        return

    df["date"] = pd.to_datetime(df["date"])
    df_month = df[df["date"].dt.strftime("%Y-%m") == month]

    if df_month.empty:
        print("⚠️ No data for this month.")
        return

    income = df_month[df_month["type"] == "income"]["amount"].sum()
    expense = df_month[df_month["type"] == "expense"]["amount"].sum()

    print("\n📊 Monthly Summary")
    print("----------------------")
    print(f"Total Income : ₹{income}")
    print(f"Total Expense: ₹{expense}")
    print(f"Net Balance  : ₹{income - expense}")


# -------------------------------
# Export CSV
# -------------------------------
def export_csv():
    os.makedirs(EXPORT_DIR, exist_ok=True)

    conn = sqlite3.connect(DB_NAME)
    df = pd.read_sql_query("SELECT * FROM transactions", conn)
    conn.close()

    path = os.path.join(EXPORT_DIR, "expenses_export.csv")
    df.to_csv(path, index=False)

    print(f"✅ Exported to {path}")


# -------------------------------
# Generate Chart
# -------------------------------
def generate_chart():
    os.makedirs(EXPORT_DIR, exist_ok=True)

    conn = sqlite3.connect(DB_NAME)
    df = pd.read_sql_query("SELECT * FROM transactions", conn)
    conn.close()

    if df.empty:
        print("⚠️ No data to plot.")
        return

    summary = df.groupby("type")["amount"].sum()

    plt.figure()
    summary.plot(kind="pie", autopct="%1.1f%%")
    plt.title("Income vs Expense")

    path = os.path.join(EXPORT_DIR, "expense_chart.png")
    plt.savefig(path)
    plt.close()

    print(f"✅ Chart saved to {path}")


# -------------------------------
# Menu
# -------------------------------
def menu():
    while True:
        print("\n====== Expense Tracker CLI ======")
        print("1. Add Entry")
        print("2. Monthly Summary")
        print("3. Export to CSV")
        print("4. Generate Chart")
        print("5. Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            add_entry()
        elif choice == "2":
            monthly_summary()
        elif choice == "3":
            export_csv()
        elif choice == "4":
            generate_chart()
        elif choice == "5":
            print("👋 Goodbye!")
            break
        else:
            print("❌ Invalid choice")


# -------------------------------
# Main
# -------------------------------
if __name__ == "__main__":
    init_db()
    menu()